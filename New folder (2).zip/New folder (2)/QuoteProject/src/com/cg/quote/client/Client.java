package com.cg.quote.client;

import java.io.IOException;
import java.util.Scanner;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.CreateAccount.role;
import com.cg.quote.service.CreateAccountServImpl;
import com.cg.quote.service.ICreateAccountServ;

public class Client {
	static Scanner scanner=new Scanner(System.in);
	static CreateAccount createBean=null;
	static ICreateAccountServ createAccServ=null;
	static String userName=null;
	static String password=null;
	public static void main(String[] args) throws IOException {
		
		createBean=new CreateAccount();
		createAccServ=new CreateAccountServImpl();
		
		System.out.println("Enter Username ");
		
		userName = scanner.next();
		createBean.setUsername(userName);
		System.out.println("Enter Password ");
		
		password = scanner.next();
		createBean.setPassword(password);
		CreateAccount.role roleCode;
	//	System.out.println(role);
		System.out.println("Enter Role Code ");
		roleCode = role.valueOf(scanner.next());
		createBean.setRole_code(roleCode);
	
		createAccServ.validateBean(createBean);
		createAccServ.createAccount(createBean);
		
	}

}

package com.cg.quote.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.CreateAccount.role;
import com.cg.quote.exception.UserNameException;
import com.cg.quote.util.DBConnection;

public class CreateAccountDaoImpl implements ICreateAccountDao{

	@Override
	public void createAccount(CreateAccount createbean) throws IOException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try
		{
				ps=connection.prepareStatement("insert into userrole values(?,?,?)");
				role roleCode = createbean.getRole_code();
				ps.setString(1,createbean.getUsername());
				ps.setString(2,createbean.getPassword());
				ps.setString(3,roleCode.name());
				ps.executeUpdate();
				System.out.println("Inserted");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
}

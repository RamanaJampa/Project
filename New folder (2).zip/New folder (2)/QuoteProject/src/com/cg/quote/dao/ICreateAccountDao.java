package com.cg.quote.dao;

import java.io.IOException;

import com.cg.quote.bean.CreateAccount;

public interface ICreateAccountDao {
	
	public void createAccount(CreateAccount createbean) throws IOException;

}
